# P2000 Apeldoorn – App Store Connect

**Bundle ID:** nl.lrvdlinden.p2000apeldoorn · **SKU:** p2000apeldoorn · **Versie:** 1.0.0 (8)
**Primaire categorie:** Nieuws · **Secundaire categorie:** Navigatie
**Prijs:** Gratis · **Beschikbaarheid:** Nederland (eventueel ook België)
**Copyright:** © 2026 PixelForges
**Support-URL:** https://p2000-apeldoorn.nl · **Marketing-URL:** https://p2000-apeldoorn.nl
**Privacybeleid-URL:** zet de privacyverklaring op een vaste pagina, bijvoorbeeld https://p2000-apeldoorn.nl/privacy. Apple verplicht een URL, en een pop-up is niet genoeg.

---

## Nederlands (primaire taal)

**Naam (30):** P2000 Apeldoorn
**Subtitel (30):** Live P2000-meldingen Apeldoorn

**Promotietekst (170):**
Alle P2000-meldingen van brandweer, ambulance, politie en traumaheli in gem. Apeldoorn: live, op de kaart en als pushmelding. Nu ook op iPad, Mac, Apple Watch en Apple TV.

**Beschrijving:**
P2000 Apeldoorn is de officiële app van p2000-apeldoorn.nl. Je ziet direct welke hulpdiensten er in de gemeente Apeldoorn worden opgeroepen: brandweer, ambulance, politie en traumaheli.

LIVE PAGER
• Alle meldingen in een overzichtelijke tijdlijn, per dag gegroepeerd
• De tellingen van vandaag per hulpdienst in één oogopslag
• Zoeken op plaats, straat of capcode, en filteren op discipline, plaats en prioriteit

OP DE KAART
• Elke melding met de vertrouwde marker per hulpdienst
• Kies de periode: 6 uur, 24 uur of 7 dagen
• Standaard, satelliet of hybride kaart

ALLE DETAILS
• Een grote kaart met Look Around-preview van de locatie
• Prioriteit, categorie, tijdstip en direct naar Apple Kaarten
• Capcodes en voertuigen die zijn gealarmeerd
• METEO-gegevens van Apple Weer, op het tijdstip en de plek van de melding

PUSHMELDINGEN
• Kies je plaatsen, disciplines en prioriteiten
• Mijn buurt: alleen meldingen binnen een straal rond je locatie of een vast punt
• Stille modus met eigen tijden
• Kritieke meldingen (A1/P1) komen ook in de stille modus door

WIDGETS
• Laatste melding, Meldingen (lijst) en Vandaag op je beginscherm, vergrendelscherm, Mac-bureaublad en Apple Watch-wijzerplaat
• Kies per widget een discipline, of gebruik de filters uit de app

STATISTIEKEN
• Vandaag, deze maand, per uur, per weekdag en per prioriteit
• De meest voorkomende soorten meldingen

MELDKAMER OP APPLE TV
• De live kaart gaat zelf langs de laatste meldingen
• Nieuwe meldingen verschijnen groot in beeld met een alarmscherm
• Grote klok, tellingen van vandaag en vandaag tegenover gisteren

OP AL JE APPARATEN
• iPhone, iPad, Mac, Apple Watch en Apple TV
• Inloggen met Apple, met je instellingen en bewaarde meldingen via iCloud gesynchroniseerd
• Vergrendelen met Face ID of Touch ID

Plaatsen: Apeldoorn, Beekbergen, Beemte-Broekland, Hoenderloo, Hoog Soeren, Klarenbeek, Lieren, Loenen, Radio Kootwijk, Teuge, Uddel, Ugchelen en Wenum-Wiesel.

Let op: niet alle meldingen van politie en ambulance staan in de app, omdat ze niet altijd via het P2000-netwerk worden verstuurd. Bel bij nood altijd 112. Deze app is geen officiële dienst van de hulpdiensten of de veiligheidsregio.

Bron: p2000.page · Made & Powered by PixelForges

**Trefwoorden (100):**
p2000,112,brandweer,ambulance,politie,lifeliner,traumaheli,meldingen,alarm,apeldoorn,gelderland,pager

**Let op voor Apple TV:** de tvOS-app gebruikt dezelfde bundle ID (universal purchase). Voeg in App Store Connect het platform *tvOS* toe aan de app en upload Apple TV-screenshots (1920 × 1080 of 3840 × 2160).

**Wat is er nieuw (1.0.0):**
Welkom bij de eerste versie van P2000 Apeldoorn voor iPhone, iPad, Mac en Apple Watch, met widgets voor je beginscherm, vergrendelscherm, bureaublad en wijzerplaat.

---

## English

**Name:** P2000 Apeldoorn
**Subtitle:** Live emergency alerts Apeldoorn

**Promotional text:**
Every P2000 alert for fire brigade, ambulance, police and trauma helicopter in Apeldoorn: live, on the map and as push notifications. On iPhone, iPad, Mac and Apple Watch.

**Description:**
P2000 Apeldoorn is the official app of p2000-apeldoorn.nl. See right away which emergency services are being dispatched in the municipality of Apeldoorn: fire brigade, ambulance, police and trauma helicopter.

• Live pager timeline with today's counts per service
• Every alert on the map, with a familiar marker per service
• Details with a large map, Look Around preview, capcodes, vehicles and Apple Weather data for the time and place of the alert
• Push notifications for your places, services, priorities and your own radius, with quiet hours and critical alerts
• Statistics by hour, weekday and priority
• Widgets for your Home Screen, Lock Screen, Mac desktop and Apple Watch face
• Apple TV control-room screen: live map, alarm screen for new alerts and today vs yesterday
• Sign in with Apple and iCloud sync across iPhone, iPad, Mac, Apple Watch and Apple TV
• Lock with Face ID or Touch ID

Not every police and ambulance alert is sent over the P2000 network, so not all of them appear in the app. In an emergency always call 112. This app is not an official service of the emergency services.

Source: p2000.page · Made & Powered by PixelForges

**Keywords:** p2000,112,fire,ambulance,police,lifeliner,emergency,alerts,apeldoorn,gelderland,pager,scanner

**What's new:** First release of P2000 Apeldoorn for iPhone, iPad, Mac and Apple Watch, with widgets for your Home Screen, Lock Screen, desktop and watch face.

---

## Leeftijdsclassificatie
- Medische/behandelingsinformatie: **niet vaak/mild**, want meldingen noemen ongevallen en ambulance-inzetten
- Verder overal "Geen". Verwachte uitkomst: **9+** of **12+**, afhankelijk van de vragenlijst.

## App-privacy (vragenlijst)
| Gegevenstype | Verzameld | Gekoppeld aan gebruiker | Tracking | Doel |
|---|---|---|---|---|
| Apparaat-ID: APNs-pushtoken | Ja, als pushmeldingen aan staan | Nee | Nee | App-functionaliteit |
| Grove locatie: middelpunt van *Mijn buurt*, afgerond op ~100 m | Ja, alleen als radius en pushmeldingen aan staan | Nee | Nee | App-functionaliteit |
| Overige gegevens: meldingsvoorkeuren (plaatsen, disciplines, prioriteit, stille modus) | Ja | Nee | Nee | App-functionaliteit |
| Naam en e-mail (Inloggen met Apple) | Nee, blijft in de iCloud van de gebruiker | – | – | – |
| Precieze locatie | Nee, de afstand wordt op het apparaat berekend | – | – | – |

Er wordt geen tracking gedaan. Er zitten geen advertentie- of analytics-SDK's in de app, en ook geen Facebook.
**Let op:** je huidige privacyverklaring gaat nog uit van de website, met tracking- en advertentiecookies. Voor de app moet er een korte app-paragraaf bij die past bij deze tabel. De tekst staat in `server/content/privacy.json`.

## Notities voor de App Review
- Je hebt geen account nodig. *Inloggen met Apple* is optioneel en zorgt alleen voor iCloud-sync en het koppelen van pushmeldingen.
- De meldingen komen uit het openbare P2000-netwerk (bron: p2000.page) en worden verwerkt door onze eigen server. De app werkt los van de website.
- WeatherKit wordt gebruikt voor de METEO-gegevens. Het Apple Weer-logo en de link naar de juridische bronnen staan op het detailscherm.

## Capabilities in de Developer-portal
- App ID `nl.lrvdlinden.p2000apeldoorn`: Sign in with Apple, Push Notifications, iCloud (Key-value storage), **App Groups** (`group.nl.lrvdlinden.p2000apeldoorn`) en **WeatherKit**. Zet WeatherKit ook aan onder *Services*.
- App ID `nl.lrvdlinden.p2000apeldoorn.widgets`: App Groups en iCloud (Key-value storage).
- App ID `nl.lrvdlinden.p2000apeldoorn.watchkitapp`: App Groups en iCloud (Key-value storage).
- App ID `nl.lrvdlinden.p2000apeldoorn.watchkitapp.widgets`: App Groups en iCloud (Key-value storage).
- Push: de eigen server verstuurt via APNs met de .p8-sleutel (GitHub-secrets `APN_KEY_ID`, `APN_TEAM_ID` en `APN_P8_CERT`). Zet bij de App ID ook *Time Sensitive Notifications* aan.

## Bestanden in dit pakket
Alle screenshots hebben exact de maten uit Apple's *Screenshot specifications* en zijn opgeslagen als PNG **zonder alfakanaal**. Maximaal 10 per apparaat; nl en en hebben elk dezelfde set.

| Map | Formaat | Waar in App Store Connect |
|---|---|---|
| `1-iPhone-6.9-inch (1320x2868)` | 1320 × 2868, 8 stuks | iPhone → **6.9" Display** |
| `2-iPhone-6.1-inch (1206x2622)` | 1206 × 2622, 8 stuks | iPhone → **6.1" Display** (Apple-klasse voor de 6,3"-iPhones; 1206 × 2622 staat daar in de lijst) |
| `3-iPad-13-inch (2752x2064)` | 2752 × 2064 liggend, 3 stuks | iPad → **13" Display** |
| `4-Mac (2880x1800)` | 2880 × 1800, 5 stuks | macOS |
| `5-Apple-Watch-Ultra (422x514)` | 422 × 514, 4 stuks (kaal scherm) | watchOS → **Ultra 3** (één Watch-maat is genoeg; Apple schaalt voor de andere) |
| `5b-Apple-Watch-Ultra-met-mockup (422x514)` | 422 × 514, 4 stuks, met kop en Watch-mockup | Zelfde Watch-vak, als alternatief voor de kale schermen (kies één van beide) |
| `6-Apple-TV (3840x2160)` | 3840 × 2160, 4 stuks | tvOS → **Apple TV** (4K) |
| `7-Apple-TV-1080p (1920x1080)` | 1920 × 1080, 4 stuks | Apple TV, als je liever 1080p uploadt (zelfde beelden) |
| `Promotional-artwork (5244x2950, 3840x2560, 1920x1280)` | 5244 × 2950, 3840 × 2560, 1920 × 1280 (+ 3840 × 1646 extra), PNG zonder alfa en zonder tekst | App Store Connect → Featuring → Promotional artwork |
| `AppIcon-1024.png` | 1024 × 1024, zonder alfa | Zit ook in het Xcode-project |
| `nl/Marketing`, `en/Marketing` | OG-image 1200×630, hero, social, story en Watch Ultra-mockups (1600×2000) | Website en social media, **niet** uploaden in App Store Connect |

### Uploaden vanuit Xcode
- **iPhone, iPad en Apple Watch:** archiveer het scheme *P2000 Apeldoorn* met bestemming *Any iOS Device*. De Watch-app en de widgets zitten daar automatisch in; de Watch hoeft niet apart.
- **Mac:** hetzelfde scheme, bestemming *Any Mac*, apart archiveren en uploaden.
- **Apple TV:** scheme *P2000 Apeldoorn TV*, bestemming *Any tvOS Device*, apart archiveren en uploaden. Zelfde bundle ID, dus het komt in hetzelfde app-record (universal purchase). Voeg in App Store Connect het platform tvOS toe.

Website-tag voor de OG-image:
```html
<meta property="og:image" content="https://p2000-apeldoorn.nl/og-image-1200x630.png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
```
